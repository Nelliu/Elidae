﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Movement : MonoBehaviour
{
    public float speed;
   
    private Vector2 input = new Vector2(0, 0);
    private Rigidbody2D rb;
    

 


    // Use this for initialization
    void Start()
    {
        rb = gameObject.GetComponent<Rigidbody2D>();
    }

    // Update is called once per frame
    void Update()
    {
        // velocity == real life gravitace
        input = rb.velocity;   //.y = -1 * speed;
        if (Input.GetKey(KeyCode.D))
        {
            input.x = speed;

        }
        if (Input.GetKey(KeyCode.A))
        {
            input.x = -speed;
        }
        if (Input.GetKey(KeyCode.W))
        {
            input.y = speed;
        }
        if(Input.GetKey(KeyCode.S))
        {
            input.y = -speed;
        }



        rb.velocity = input;        // objekt bde rizen gravitaci
    }

   


}
